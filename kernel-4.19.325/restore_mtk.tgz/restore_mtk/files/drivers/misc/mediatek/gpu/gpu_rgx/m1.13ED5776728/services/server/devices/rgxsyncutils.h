/*************************************************************************/ /*!
@File           rgxsyncutils.h
@Title          RGX Sync Utilities
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    RGX Sync helper functions
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

#ifndef RGXSYNCUTILS_H
#define RGXSYNCUTILS_H

#include "rgxdevice.h"
#include "sync_server.h"
#include "rgxdebug.h"
#include "rgx_fwif_km.h"

typedef struct _RGX_SYNC_DATA_
{
	PRGXFWIF_UFO_ADDR *pauiClientUpdateUFOAddress;
	IMG_UINT32 *paui32ClientUpdateValue;
	IMG_UINT32 ui32ClientUpdateValueCount;
	IMG_UINT32 ui32ClientUpdateCount;

	PRGXFWIF_UFO_ADDR *pauiClientPRUpdateUFOAddress;
	IMG_UINT32 *paui32ClientPRUpdateValue;
	IMG_UINT32 ui32ClientPRUpdateValueCount;
	IMG_UINT32 ui32ClientPRUpdateCount;
} RGX_SYNC_DATA;

//#define TA3D_CHECKPOINT_DEBUG

#if 0 //defined(TA3D_CHECKPOINT_DEBUG)
void _DebugSyncValues(IMG_UINT32 *pui32UpdateValues,
					  IMG_UINT32 ui32Count);

void _DebugSyncCheckpoints(PSYNC_CHECKPOINT *apsSyncCheckpoints,
						   IMG_UINT32 ui32Count);
#endif

PVRSRV_ERROR RGXSyncAppendTimelineUpdate(IMG_UINT32 ui32FenceTimelineUpdateValue,
										 SYNC_ADDR_LIST	*psSyncList,
										 SYNC_ADDR_LIST	*psPRSyncList,
										 PVRSRV_CLIENT_SYNC_PRIM *psFenceTimelineUpdateSync,
										 RGX_SYNC_DATA *psSyncData,
										 IMG_BOOL bKick3D);

#endif /* RGXSYNCUTILS_H */

/******************************************************************************
 End of file (rgxsyncutils.h)
******************************************************************************/
