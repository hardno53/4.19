// SPDX-License-Identifier: GPL-2.0
/* Stub simbol vendor MTK yang tidak ada di 4.19 (AEE, vcorefs, mmdvfs). */
#include <linux/kernel.h>
#include <linux/types.h>

void aee_kernel_warning_api_func(const char *file, const int line,
		const int db_opt, const char *module, const char *msg, ...)
{
}

int aee_is_printk_too_much(const char *module)
{
	return 0;
}

int vcorefs_request_dvfs_opp(int kicker, int opp)
{
	return 0;
}

void mmdvfs_set_max_camera_hrt_bw(u32 bw)
{
}
