set -e
grep -q 'shim/' drivers/misc/mediatek/Makefile || echo 'obj-y += shim/' >> drivers/misc/mediatek/Makefile
rm -f apply_disp3.sh
