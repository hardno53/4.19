set -e
n=$(grep -n '^endmenu' drivers/misc/Kconfig | tail -1 | cut -d: -f1)
grep -q 'misc/mediatek/Kconfig' drivers/misc/Kconfig || sed -i "${n}i source \"drivers/misc/mediatek/Kconfig\"" drivers/misc/Kconfig
grep -q 'CONFIG_MEDIATEK_SOLUTION' drivers/misc/Makefile || echo 'obj-$(CONFIG_MEDIATEK_SOLUTION) += mediatek/' >> drivers/misc/Makefile
F=arch/arm64/configs/a02_64_bootstrap_defconfig
for l in 'CONFIG_MEDIATEK_SOLUTION=y' 'CONFIG_MTK_PLATFORM="mt6739"' 'CONFIG_ARCH_MTK_PROJECT="a02"' 'CONFIG_MACH_MT6739=y' 'CONFIG_MTK_SYNC=y' 'CONFIG_MMPROFILE=y' 'CONFIG_MTK_MMPROFILE_SUPPORT=y' 'CONFIG_MTK_SMI_EXT=y'; do grep -qxF "$l" $F || echo "$l" >> $F; done
rm -f apply_disp1.sh
