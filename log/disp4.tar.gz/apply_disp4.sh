set -e
F=arch/arm64/configs/a02_64_bootstrap_defconfig
for l in 'CONFIG_MTK_M4U=y' 'CONFIG_MTK_CMDQ=y' 'CONFIG_MTK_CMDQ_V3=y'; do grep -qxF "$l" $F || echo "$l" >> $F; done
rm -f apply_disp4.sh
