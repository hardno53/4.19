set -e
grep -q 'mtk-smi-debug' drivers/memory/Makefile || sed -i 's/^obj-\$(CONFIG_MTK_SMI)\(.*\)mtk-smi\.o.*/obj-$(CONFIG_MTK_SMI)\t\t+= mtk-smi.o mtk-smi-debug.o/' drivers/memory/Makefile
grep -n 'mtk-smi' drivers/memory/Makefile
rm -f apply_disp2.sh
